DROP TABLE IF EXISTS `#__contactdb_messages`;
